package com.honeywell.fitness.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.honeywell.fitness.entity.User;
import com.honeywell.fitness.repository.UserRepository;
import com.honeywell.fitness.vo.UserVO;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<User> findCoaches(String role,String location) {
		List<User> findByRole = userRepository.findByRoleAndLocation(role,location);
		System.out.println("in service "+userRepository.findByRoleAndLocation(role,location));
		return findByRole;
	}

	@Override
	public User createUser(UserVO userVo) {
		User user=new User();
		BeanUtils.copyProperties(userVo, user);
		return userRepository.save(user);
	}

}
